﻿using UnityEngine;
using System.Collections;

/****************************************
	Kinectで認証してプレイヤーを決定し、利き手を選択する

	Kinectを扱うViewクラスから手の高さをもらい、
	一定時間あげた方の手を利き手としてラケットを合わせます
	
*****************************************/
public class TitleM : MonoBehaviour {
	public static bool handSelect;							//利き手が選択できているかどうか
	public static AudioSource audio;						//タイトルのBGMを流す
	public static bool start = true;						//ゲーム起動時に一度だけ実行
	public static bool titlestart = true;							//タイトル開始時に一度だけ実行
	public static bool goGame;

	public AudioClip bgm;									//BGM

	public GameObject rhp;									//右手のゲージ
	public GameObject lhp;									//左手のゲージ
	public GameObject r;									//右手のゲージ
	public GameObject l;									//左手のゲージ

	public GameObject[] modesentaku = new GameObject[3];	//モード選択を行うゲームオブジェクトへの参照


	public int vec;											//ゲージの角度
	float jumpcnt;
	GUIText kaisetu;
	// Use this for initialization
	void Start () {
		GM.raketnum = 0;

	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetMouseButtonDown (1)) {
			Application.LoadLevel ("purezen");
			GM.raketnum = 0;

		}
		//タイトルが始まった時に初期化とBGMを再生
		if (titlestart) {

			jumpcnt = 0;
			GM.raketnum = 0;
			GM.raricnt = 0;
			GM.plscore = 0;
			GM.enscore = 0;
			Application.targetFrameRate = 150;
			handSelect = false;

			vec = 0;
			audio = GetComponent<AudioSource> ();
			audio.PlayOneShot (bgm);
			goGame = false;
			titlestart = false;

			r = GameObject.Find ("Sphere (4)");
			//Debug.Log (GameObject.Find ("Sphere (4)"));
			l = GameObject.Find ("Sphere (3)");
			modesentaku[0] = GameObject.Find ("Sphere");
			modesentaku[1] = GameObject.Find ("Sphere (1)");
			modesentaku[2] = GameObject.Find ("Sphere (2)");
			kaisetu = GameObject.Find("kaisetutext").GetComponent<GUIText>();
			r.SetActive (false);
			//Debug.Log (GameObject.Find ("Sphere (4)"));
			l.SetActive (false);
			modesentaku[0].SetActive (false);
			modesentaku[1].SetActive (false);
			modesentaku[2].SetActive (false);
			rhp = r;
			lhp = l;
			kaisetu.text = "せんのうえにたって";
		}
		//利き手選択のゲージが参照できていないなら探す


		//if(!modesentaku[2])modesentaku[2] = GameObject.Find ("Sphere (2)");
			//titlestart = false;

		/*ゲーム開始時に最初にできたGM(ゲームマスターオブジェクト）を残し
		、タイトルに戻ってきたときに作られる新しいGMを削除する          */
		if (start) {
			GameObject.Find ("GM").name = "GM1";

			start = false;
		} else {
			if(GameObject.Find ("GM")) {
				GameObject.Destroy (GameObject.Find ("GM"));
			}
		}

		//ゲージオブジェクトが存在していたら
		if (rhp) {
			//Kinectが人を認識していたら
			if (View.active) {
				if(handSelect == false)
				kaisetu.text = "ききてをせんたくしてね";
				//Debug.Log ("ninsiki");
				if(jumpcnt > 0) {
					jumpcnt -= Time.deltaTime;
					modesentaku[2].transform.position += new Vector3(0,0,-12*Time.deltaTime);
					if(jumpcnt <= 0) {
						GM.mode = 2;
						Application.targetFrameRate = 80;
						audio.Stop();
						rhp = null;
						lhp = null;
						goGame = true;
						Application.LoadLevel("test");
					}
				}else {
					//ゲージオブジェクトが非表示の場合表示する
					if (rhp.activeSelf == false) {
						rhp.SetActive (true);
					}
					if (lhp.activeSelf == false) {
						lhp.SetActive (true);
					}
				//Debug.Log(vec);
					if (View.rhandheight > 6) {//右手を挙げていたら
					if(vec < 0) vec = 0;
						//ゲージを回す
						vec+=2;
						
						rhp.transform.FindChild ("meta").transform.position = rhp.transform.position + 
							new Vector3 (Mathf.Sin (vec * 3.14f / 180) * rhp.transform.localScale.x / 2, Mathf.Cos (vec * 3.14f / 180) * rhp.transform.localScale.x / 2, 0);
						rhp.transform.FindChild ("meta").transform.localEulerAngles = new Vector3 (0, 0, -vec);
						//ゲージが一定量回転したら利き手を右手にする
						if (vec > 360) {
							if (handSelect == false) {
							handSelect = true;
								kaisetu.text = "モードをせんたくしてね";
							View.kikite = true;
								vec = 0;
							rhp.SetActive(false);
							lhp.SetActive(false);
							rhp = modesentaku[0];
							lhp = modesentaku[1];
							}else {
								GM.mode = 0;
								Application.targetFrameRate = 80;
								audio.Stop();
							goGame = true;
							rhp = null;
							lhp= null;
								Application.LoadLevel("test");
							}
						}
					}else  if (View.lhandheight > 6) {//左手を挙げていたら
					if(vec > 0) vec = 0;
						//ゲージを回す
						vec-=2;
						lhp.transform.FindChild ("meta").transform.position = lhp.transform.position + 
							new Vector3 (Mathf.Sin (vec * 3.14f / 180) * lhp.transform.localScale.x / 2, Mathf.Cos (vec * 3.14f / 180) * lhp.transform.localScale.x / 2, 0);
						lhp.transform.FindChild ("meta").transform.localEulerAngles = new Vector3 (0, 0, -vec);
						//ゲージが一定量回転したら利き手を左手にする
						if (vec < -360) {
							if (handSelect == false) {
							handSelect = true;
								kaisetu.text = "モードをせんたくしてね";
							View.kikite = false;
								vec = 0;
							lhp.SetActive(false);
							rhp.SetActive(false);
							lhp = modesentaku[1];
							rhp = modesentaku[0];
							}
							else {
								GM.mode = 1;
								Application.targetFrameRate = 80;
								audio.Stop();
							rhp = null;
							lhp = null;
							goGame = true;
								Application.LoadLevel("test");
							}
						}

					} else {//両手を挙げていなかったら
						//角度を0にしてゲージを戻す
						vec = 0;
						rhp.transform.FindChild ("meta").transform.position = rhp.transform.position + 
							new Vector3 (Mathf.Sin (vec * 3.14f / 180) * rhp.transform.localScale.x / 2, Mathf.Cos (vec * 3.14f / 180) * rhp.transform.localScale.x / 2, 0);
						rhp.transform.FindChild ("meta").transform.localEulerAngles = new Vector3 (0, 0, -vec);
						lhp.transform.FindChild ("meta").transform.position = lhp.transform.position + 
							new Vector3 (Mathf.Sin (vec * 3.14f / 180) * lhp.transform.localScale.x / 2, Mathf.Cos (vec * 3.14f / 180) * lhp.transform.localScale.x / 2, 0);
						lhp.transform.FindChild ("meta").transform.localEulerAngles = new Vector3 (0, 0, -vec);
					}
					if(handSelect) {
						if(View.jump) {
							jumpcnt = 3;
							modesentaku[2].SetActive(true);
						}
					}
				}
			} else {
				kaisetu.text = "せんのうえにたって";
				//Kinectが認識していないならゲージオブジェクトを表示しない
				if (rhp.activeSelf) {
					rhp.SetActive (false);
					lhp.SetActive (false);
				}
				//認識していて外れた場合、利き手を選択していない状態にする
				if(handSelect) {
					handSelect = false;

					rhp = r;
					//Debug.Log (GameObject.Find ("Sphere (4)"));
					lhp = l;
					rhp.SetActive(true);
					//Debug.Log (GameObject.Find ("Sphere (4)"));
					lhp .SetActive(true);
				}
			}
		}
		//Escapeで終了
		if (Input.GetKey (KeyCode.Escape))
			Application.Quit ();
	}
}
