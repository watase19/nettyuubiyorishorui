#include "DxLib.h"
#include<math.h>




int key_down[256];

struct Vector2_struct{
	float x;
	float y;
}typedef Vector2;


void Input_Key();
Vector2 Rotate(float x, float y, float rot);


class obj {
protected:
	float x, y, z;
	VECTOR vec;
	float rot_y;
	Vector2 size;
	Vector2 hit_gap;
	int states;
public:
	obj() {
		x = 0; y = 0; z = 0;
		vec.x = 0;
		vec.y = 0;
		vec.z = 0;
		rot_y = 0;
		size.x = 0;
		size.y = 0;
		hit_gap.x = 0;
		hit_gap.y = 0;
	}

	void data_set(float xx, float yy, float sx, float sy,float rot,int s){
		x = xx;
		y = yy;
		rot_y = rot;
		size.x = sx;
		size.y = sy;
		states = s;
	}
	//virtual void draw();
	void set_pos(float xx, float yy, float zz) {
		x = xx;
		y = yy;
		z = zz;

	}
	void set_vec(float xx, float yy, float zz) {
		vec.x = xx;
		vec.y = yy;
		vec.z = zz;

	}
	void set_rot_y(float n) {
		rot_y = n;
	}
	void move(float xx, float yy, float zz) {
		x += xx;
		y += yy;
		z += zz;
	}
	void vec_plus(float xx, float yy, float zz) {
		vec.x += xx;
		vec.y += yy;
		vec.z += zz;
	}
	void fall() {

		vec.y -= 0.1f;

	}
	void update() {
		x += vec.x;
		y += vec.y;
		z += vec.z;
	}
	VECTOR get_pos() {
		VECTOR buf_pos = VGet(x, y, z);
		return buf_pos;
	}
	VECTOR get_vec() {
		return vec;
	}
	Vector2 get_size() {
		return size;
	}
	float get_rot_y() {
		return rot_y;
	}
	void move_rot_y(float n) {
		rot_y += n;
	}
	Vector2 get_gap() {
		return hit_gap;
	}
	int get_states() {
		return states;
	}
	virtual void draw(){

	}
};

class sphere:public obj {
public :
	sphere() {
		y = 200;
	}
	virtual void draw() {
		DrawSphere3D(VGet(x, y, z), size.x, 32, GetColor(255, 255, 255), GetColor(255, 255, 255), TRUE);
	}
	bool hit(obj o2) {
		bool ret = false;
		Vector2 gap = o2.get_gap();
		float buf_x, buf_y;
		float len = sqrt((x - (o2.get_pos().x + gap.x / 2))*
			(x - (o2.get_pos().x + gap.x / 2)) +
			(y - (o2.get_pos().y + gap.y / 2))*
			(y - (o2.get_pos().y + gap.y / 2)));
		float deg = o2.get_rot_y() * 180 / 3.14f;
		float deg_sa = atan2(y - o2.get_pos().y, x - o2.get_pos().x);
		deg_sa -= deg;
		buf_x = o2.get_pos().x+len*cos(deg/180*3.14f);
		buf_y = o2.get_pos().y + len*sin(deg / 180 * 3.14f);

		buf_x = o2.get_pos().x + Rotate(x - (o2.get_pos().x), y - (o2.get_pos().y), deg_sa*3.14f / 180).x;
		buf_y = o2.get_pos().y + Rotate(x - (o2.get_pos().x), y - (o2.get_pos().y), deg_sa*3.14f / 180).y;
		/*DrawFormatString(0, 25, GetColor(255, 255, 255), "%f,%f,%f", vec.x, vec.y,deg);
		DrawSphere3D(VGet(buf_x, buf_y, z), 5.0f, 32, GetColor(255, 0, 0), GetColor(255, 0, 0), TRUE);
		DrawFormatString(0, 50, GetColor(255, 255, 255), "%f,%f,%f", buf_x, buf_y, len);*/
		//buf_x = x;
		//buf_y = y;
		float size_x = o2.get_size().x;
		float gap_x = o2.get_gap().x;
		if (size_x< 0) {
			size_x *= -1;
			gap_x *= -1;
		}
		DrawFormatString(0, 25, GetColor(255, 255, 255), "%f", size_x);
		if (buf_x + size.x / 2+vec.x> o2.get_pos().x - size_x / 2 + gap_x/2 &&
			buf_x - size.x / 2 + vec.x  < o2.get_pos().x + size_x / 2 + gap_x / 2 &&
			buf_y + size.y / 2 + vec.y> o2.get_pos().y - o2.get_size().y / 2 + o2.get_gap().y / 2 &&
			buf_y - size.y / 2 + vec.y < o2.get_pos().y + o2.get_size().y / 2 + o2.get_gap().y / 2) {

			//x = buf_x;
			//y = buf_y;
			//DrawFormatString(0, 100, GetColor(255, 255, 255), "hit");
			ret = true;
		}
		return ret;
	}
};
class cube :public obj {
public:
	cube() {
		vec.y = 0;
		size.x = 20;
		size.y = 10;
		x = 10;
		y = 20;
	}
	virtual void draw() {

		float si,co;
		Vector2 triangle1[3];
		Vector2 buf;
		triangle1[0].x = -size.x/2;
		triangle1[0].y = size.y/2;
		triangle1[1].x = size.x/2;
		triangle1[1].y = size.y/2;
		triangle1[2].x = -size.x/2;
		triangle1[2].y = -size.y/2;
		
		for (int i = 0; i < 3; i++) {
			buf = Rotate(triangle1[i].x, triangle1[i].y, rot_y);
			triangle1[i].x = x + buf.x;
			triangle1[i].y = y + buf.y;
		}
		
		Vector2 triangle2[3];
		triangle2[0].x = size.x/2;
		triangle2[0].y = size.y/2;
		triangle2[1].x = -size.x/2;
		triangle2[1].y = -size.y/2;
		triangle2[2].x = size.x/2;
		triangle2[2].y = -size.y/2;
		for (int i = 0; i < 3; i++) {
			buf = Rotate(triangle2[i].x, triangle2[i].y, rot_y);
			triangle2[i].x = x + buf.x;
			triangle2[i].y = y + buf.y;
		}

		DrawTriangle3D(VGet(triangle1[0].x, triangle1[0].y, z),
			VGet(triangle1[1].x, triangle1[1].y, z),
			VGet(triangle1[2].x, triangle1[2].y, z), GetColor(255, 255, 255), TRUE);
		DrawTriangle3D(VGet(triangle2[0].x, triangle2[0].y, z),
			VGet(triangle2[1].x, triangle2[1].y, z),
			VGet(triangle2[2].x, triangle2[2].y, z), GetColor(255, 255, 255), TRUE);
	}
};
class bar :public obj {
public:
	bar() {
		vec.y = 0;
		x = 10;
		y = 20;
		hit_gap.x = 15;
		hit_gap.y = -3;
		rot_y = 180*3.14f/180;
	}

	virtual void draw() {

		float si, co;
		Vector2 triangle1[3];
		Vector2 buf;
		triangle1[0].x = 0;
		triangle1[0].y = 0;
		triangle1[1].x = size.x;
		triangle1[1].y = 0;
		triangle1[2].x = 0;
		triangle1[2].y = -size.y;

		for (int i = 0; i < 3; i++) {
			buf = Rotate(triangle1[i].x, triangle1[i].y, rot_y);
			triangle1[i].x = x + buf.x;
			triangle1[i].y = y + buf.y;
		}

		Vector2 triangle2[3];
		triangle2[0].x = size.x;
		triangle2[0].y = 0;
		triangle2[1].x = 0;
		triangle2[1].y = -size.y;
		triangle2[2].x = size.x;
		triangle2[2].y = -size.y;
		for (int i = 0; i < 3; i++) {
			buf = Rotate(triangle2[i].x, triangle2[i].y, rot_y);
			triangle2[i].x = x + buf.x;
			triangle2[i].y = y + buf.y;
		}

		DrawTriangle3D(VGet(triangle1[0].x, triangle1[0].y, z),
			VGet(triangle1[1].x, triangle1[1].y, z),
			VGet(triangle1[2].x, triangle1[2].y, z), GetColor(255, 255, 255), TRUE);
		DrawTriangle3D(VGet(triangle2[0].x, triangle2[0].y, z),
			VGet(triangle2[1].x, triangle2[1].y, z),
			VGet(triangle2[2].x, triangle2[2].y, z), GetColor(255, 255, 255), TRUE);
	}
};



int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int){
   ChangeWindowMode(TRUE); // �E�B���h�E���[�h�ɐݒ�
   SetGraphMode(800, 800,32);
   SetWindowSize(400, 600);
   DxLib_Init();	// DX���C�u��������������
   // �y�o�b�t�@��L���ɂ���
   SetUseZBuffer3D(TRUE);

   // �y�o�b�t�@�ւ̏������݂�L���ɂ���
   SetWriteZBuffer3D(TRUE);
   //���s0.1�`1000�܂ł��J�����̕`��͈͂Ƃ���
   SetCameraNearFar(0.1f, 1000.0f);

   //(0,10,-20)�̎��_����(0,10,0)�̃^�[�Q�b�g������p�x�ɃJ������ݒu
   SetCameraPositionAndTarget_UpVecY(VGet(115,50, -200), VGet(115.0f, 50, -0.0f));

   ChangeLightTypeDir(VGet(0.0f, 0.0f, 50.0f));
   int color = GetColor(255, 255, 255);
   int x = 0,z = 0;
   sphere sph;
   int quake_tim = 0;

   sphere gimic_sph[5];
   bar ba,ba2;
   cube cub[30];
   cub[0].data_set(114.5, 80,170,3,1.57,0);
   cub[1].data_set(104.5, 80, 170, 3, 1.57,0);
   cub[2].data_set(0, 80, 170, 3, -1.57, 0);

   cub[3].data_set(100, -25, 0, 8, 1.57, 0);
   cub[4].data_set(7.5, -25, 0, 8, -1.57, 0);
   cub[5].data_set(87.5, 30, 30, 5, 1.57, 0);
   cub[6].data_set(20, 30, 30, 5, -1.57, 0);

   cub[7].data_set(80, 12, 20, 5, 30 * 3.14f / 180, 1);
   cub[8].data_set(27.5, 12, 20, 5, 330 * 3.14f / 180, 1);

   cub[9].data_set(95, 60, 15, 5, 30 * 3.14f / 180, 1);
   cub[10].data_set(10.5, 60, 15, 5, 330 * 3.14f / 180, 1);
   ba.data_set(37.5, 9, 15, 3, 330 * 3.14f / 180, 2);

   ba2.data_set(70, 9, -15, 3, 30 * 3.14f / 180, 2);

   sph.data_set(40, 100, 3, 3,0,0);
   gimic_sph[0].data_set(40, 130, 7, 3, 0, 3);
   gimic_sph[1].data_set(80, 100, 7, 3, 0, 3);
   gimic_sph[2].data_set(25, 80, 7, 3, 0, 3);
   gimic_sph[3].data_set(87.5, 45, 2, 3, 0, 3);
   gimic_sph[4].data_set(20, 45, 2, 3, 0, 3);
   obj* task[30];
   task[0] = &ba;
   task[1] = &ba2;

   int score = 0;

   float bar_move_cnt[2] = { 0 };
   for (int i = 0; i < 11; i++) {
	   task[i + 2] = &cub[i];
   }
   for (int i = 0; i < 5; i++) {
	   task[i + 13] = &gimic_sph[i];
   }
   while (ScreenFlip() == 0 && ProcessMessage() == 0 && ClearDrawScreen() == 0){
	   Input_Key();
	   if (key_down[KEY_INPUT_RIGHT] > 0) {
		   /*ba.move(0.01f, 0, 0);// */ba2.move_rot_y(0.1);
		  // sph.move(1, 0, 0);
	   }
	   if (key_down[KEY_INPUT_LEFT] > 0){
		   /*ba.move(-0.01f, 0, 0);*/ba2.move_rot_y(-0.1);
		   //sph.move(-1, 0, 0);
	   }
	   if (key_down[KEY_INPUT_Z] > 0)
		   /*ba.move(0.01f, 0, 0);// *///ba.move_rot_y(0.1);
		   bar_move_cnt[0] = 30;
	   if (key_down[KEY_INPUT_X] >0)
		   /*ba.move(-0.01f, 0, 0);*///ba.move_rot_y(-0.1);
		   bar_move_cnt[1] = 30;

	   if (key_down[KEY_INPUT_UP] == 1)
		   if(quake_tim == 0) quake_tim = 9;
	   if (sph.get_pos().y+sph.get_vec().y <-20) {
		  sph.set_pos(65, 200, sph.get_pos().z);
		  sph.set_vec(0, 0, 0);
	   }
	   if (bar_move_cnt[0] > 0) {
		   if (ba.get_rot_y() / 3.14 * 180 <410) {
			   ba.move_rot_y(0.2);
			   bar_move_cnt[0] --;
		   }
		   else {

			   bar_move_cnt[0] =0;
		   }
	   }
	   else {
		   if (ba.get_rot_y() / 3.14 * 180 > 340){
			   ba.move_rot_y(-0.2);
		   }
		   else {
			   ba.set_rot_y(330 * 3.14f / 180);
		   }
	   }
	   
	   if (bar_move_cnt[1] > 0) {
		   if (ba2.get_rot_y() / 3.14 * 180 >-50) {
			   ba2.move_rot_y(-0.2);
			   bar_move_cnt[1] --;
		   }
		   else {

			   bar_move_cnt[1] = 0;
		   }
	   }
	   else {
		   if (ba2.get_rot_y() / 3.14 * 180 <20){
			   ba2.move_rot_y(0.2);
		   }
		   else {
			   ba2.set_rot_y(30 * 3.14f / 180);
		   }
	   }

	   DrawFormatString(0, 0, color, "s:%d,%f", quake_tim, ba2.get_rot_y()/3.14*180);

	   if (quake_tim > 0) quake_tim--;
	   sph.fall();
	   for (int i = 0; i < 18; i++) {
		   if (quake_tim > 0) {
			   if (quake_tim > 4) {
				   task[i]->move(0.5,0,0);

			   }
			   else {

				   task[i]->move(-0.5, 0, 0);
			   }
		   }
		   float deg = atan2(sph.get_pos().y - (task[i]->get_pos().y + task[i]->get_gap().y / 2), sph.get_pos().x - (task[i]->get_pos().x + task[i]->get_gap().x / 2)) / 3.14f * 180;
		   
		   if (sph.hit(*task[i])) {
			  // 
			   sph.set_vec(sph.get_vec().x,/* -sph.get_vec().y*0.8*/0, sph.get_vec().z);
			   
			   if (task[i]->get_states() == 3) {
				   sph.set_vec(-cos(deg)*3,sin(deg)*3, sph.get_vec().z);

				   score += 10;
			   }
			   else if (task[i]->get_states() == 0) {
				   if (sph.get_vec().x > 0) {
					   sph.set_pos(task[i]->get_pos().x - task[i]->get_size().y / 2-sph.get_size().x*1.5,sph.get_pos().y,sph.get_pos().z);
					   sph.set_vec(0,0,0);
				   }
				   else if (sph.get_vec().x < 0) {
					   sph.set_vec(0, 0, 0);
					   sph.set_pos(task[i]->get_pos().x + task[i]->get_size().y / 2 + sph.get_size().x*1.5, sph.get_pos().y, sph.get_pos().z);
				   }
				   if (sph.get_vec().y > 0) {
					   sph.set_pos(sph.get_pos().x, task[i]->get_pos().x - task[i]->get_size().y / 6, sph.get_pos().z);
				   }
				   else if (sph.get_vec().y < 0) {
					   sph.set_pos(sph.get_pos().x, task[i]->get_pos().x + task[i]->get_size().y / 6, sph.get_pos().z);
				   }
			   }
			   else {
				   /*if ((deg - task[i]->get_rot_y() > 80) && (deg - task[i]->get_rot_y() < 100) ||
					   (-deg + task[i]->get_rot_y() > 80) && (-deg+task[i]->get_rot_y() < 100)) {
					   sph.set_vec(0, -sph.get_vec().y*0.8, 0);


					   }
					   else {*/

				   float rot = task[i]->get_rot_y() * 180 / 3.14;
				   float len = sqrt((sph.get_pos().x - (task[i]->get_pos().x))*
					   (sph.get_pos().x - (task[i]->get_pos().x)) +
					   (sph.get_pos().y - (task[i]->get_pos().y))*
					   (sph.get_pos().y - (task[i]->get_pos().y)));

				   if (task[i]->get_pos().y + sin(task[i]->get_rot_y())*(len - 1.5f) < task[i]->get_pos().y + sin(task[i]->get_rot_y())*(len + 1.5f)) {
					   sph.vec_plus(-0.1f, 0, 0);
				   }
				   else  if (task[i]->get_pos().y + sin(task[i]->get_rot_y())*(len - 1.5f) > task[i]->get_pos().y + sin(task[i]->get_rot_y())*(len + 1.5f))
				   {

					   sph.vec_plus(0.1f, 0, 0);
				   }
				   if (task[i]->get_states() == 2) {
					   if (bar_move_cnt[i] > 0) {
						   sph.set_vec(cos(task[i]->get_rot_y()+1.57)*5, sin(task[i]->get_rot_y()+1.57)*5, 0);

					   }
				   }
			   }
			   
				 //  if (rot <160) rot = rot - 180;
				  // sph.vec_plus(cos(rot / 180 * 3.14), sin(rot / 180 * 3.14), 0);

				  
			  // }
			   
		   }

	   }
	   /*if (sph.hit(ba) || sph.hit(ba2)) {
		  
		   
		  // sph.set_pos(sph.get_pos().x, ba.get_pos().y+ba.get_size().y/2*((sph.get_vec().y>0)?1:-1), sph.get_pos().z);
	   }*/

	//if (key_down[KEY_INPUT_SPACE])

	   sph.update();
	   sph.draw();
	   ba.draw();
	   for (int i = 0; i < 11; i++) {
		   cub[i].draw();
	   }
	   for (int i = 0; i < 5; i++) {
		   gimic_sph[i].draw();
	   }
	   ba2.draw();

	   
   }
   DxLib_End();	// DX���C�u�����I������
   return 0;
}


void Input_Key() {
	char tempKey[256];
	GetHitKeyStateAll(tempKey);
	for (int i = 0; i < 256; i++) {
		if (tempKey[i] == 0) {
			key_down[i] = 0;
		}
		else {
			if (key_down[i] < 60)
			key_down[i]++;
		}

	}
}

Vector2 Rotate(float x, float y, float rot) {
	Vector2 ret;
	ret.x = x*cos(rot) - y*sin(rot);

	ret.y = x*sin(rot) + y*cos(rot);

	return ret;
}